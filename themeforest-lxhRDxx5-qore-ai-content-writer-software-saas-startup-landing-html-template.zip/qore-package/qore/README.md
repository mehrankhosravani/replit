# qore

sass asset/scss/app.scss asset/css/styles.css --watch
